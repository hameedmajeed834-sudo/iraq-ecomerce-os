import { Controller, Get, Module } from '@nestjs/common';

@Controller('health')
class HealthController {
  @Get()
  getHealth() {
    return {
      status: 'ok',
      service: 'iraq-commerce-os-api',
      version: '0.1.0',
      note: 'Liveness only; dependencies are not checked by this endpoint.'
    };
  }
}

@Module({ controllers: [HealthController] })
export class AppModule {}
