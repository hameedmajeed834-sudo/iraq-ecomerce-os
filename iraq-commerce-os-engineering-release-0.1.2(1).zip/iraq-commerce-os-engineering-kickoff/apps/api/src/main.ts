import 'dotenv/config';
import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import helmet from 'helmet';
import { AppModule } from './module';

function readPort(rawPort: string | undefined): number {
  if (rawPort === undefined || rawPort.trim() === '') return 3000;
  const port = Number(rawPort);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('PORT must be an integer between 1 and 65535.');
  }
  return port;
}

function readCorsOrigins(rawOrigins: string | undefined): string[] {
  if (!rawOrigins?.trim()) return [];
  return [...new Set(rawOrigins.split(',').map((origin) => origin.trim()).filter(Boolean))];
}

async function bootstrap() {
  const port = readPort(process.env.PORT);
  const corsOrigins = readCorsOrigins(process.env.CORS_ORIGINS);
  const app = await NestFactory.create(AppModule, {
    bodyParser: true,
  });

  app.use(helmet());
  app.setGlobalPrefix('api/v1');
  app.enableShutdownHooks();
  app.enableCors({
    origin: corsOrigins.length ? corsOrigins : false,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  });

  await app.listen(port, '0.0.0.0');
}

void bootstrap().catch((error: unknown) => {
  console.error('API startup failed:', error);
  process.exitCode = 1;
});
