# Architecture Decisions (Initial)

1. **Modular monolith first:** reduce operational complexity while domain boundaries are still evolving.
2. **PostgreSQL as the transactional source of truth:** catalog, offers, inventory and orders must not rely on caches as the source of truth.
3. **Canonical product vs seller offer:** one product can have multiple seller-specific offers; price and availability belong to offers/inventory.
4. **Integer money:** store IQD amounts as integer minor units / whole dinars according to a documented domain convention; never use floating-point arithmetic for money. Current schema uses `BigInt` fields named `*Iqd`; document the chosen unit consistently before adding payment logic.
5. **AI is advisory/orchestration, not authority:** AI must not bypass permissions, pricing rules, inventory constraints, approvals or audit.
6. **External regulated services:** use licensed payment providers; do not store card credentials.
7. **Explicit CORS allowlist:** browser origins are configured via environment and are disabled if no origin list is supplied.
8. **Baseline security middleware:** Helmet is enabled, but authentication, authorization, rate limiting, validation, observability and a security review are still required.
9. **No premature microservices:** extract services only when measured scaling, team ownership or reliability requirements justify it.

These are initial engineering decisions, not proof that the system is production-ready.
