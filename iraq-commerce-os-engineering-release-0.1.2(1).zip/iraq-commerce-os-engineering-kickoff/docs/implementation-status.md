# Implementation Status

Last engineering update: Release 0.1.1 (scaffold hardening)

| Area | Status | Evidence / next gate |
|---|---|---|
| Repository skeleton | Implemented, not build-verified | Workspace and app/package manifests exist |
| API liveness | Implemented, not runtime-tested | `GET /api/v1/health` controller |
| Environment loading | Implemented, not runtime-tested | `dotenv/config` loaded before bootstrap |
| Port validation | Implemented, not unit-tested | Startup rejects non-integer or out-of-range `PORT` |
| CORS policy | Implemented, not integration-tested | Exact origins from `CORS_ORIGINS`; disabled when empty |
| Security headers | Implemented, not runtime-tested | Helmet middleware |
| PostgreSQL / Redis | Configured only | Compose file exists; services not started here |
| Prisma data model | Draft only | No versioned migration or production review yet |
| Authentication / authorization | Not implemented | OTP, sessions, roles and resource-level policy remain open |
| Commerce transactions | Not implemented | Stock reservation, order idempotency and ledger remain open |
| Production readiness | Not ready | Build, tests, threat review, deployment and operations required |

## Acceptance gate A — local boot

Do not mark this gate passed until a developer has:
1. Copied `.env.example` to `.env`.
2. Installed dependencies with `pnpm install`.
3. Started PostgreSQL and Redis with Docker Compose.
4. Built the workspace successfully.
5. Started the API and received HTTP 200 from `/api/v1/health`.
6. Confirmed startup rejects an invalid `PORT` and browser CORS works only for configured origins.
