import { readFile, access } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = process.cwd();
const checks = [];
const check = (name, condition, detail = '') => checks.push({ name, passed: Boolean(condition), detail });
const read = (path) => readFile(resolve(root, path), 'utf8');
const exists = async (path) => { try { await access(resolve(root, path)); return true; } catch { return false; } };

for (const path of ['package.json', 'apps/api/package.json', 'packages/database/package.json']) {
  try { JSON.parse(await read(path)); check(`Valid JSON: ${path}`, true); }
  catch (error) { check(`Valid JSON: ${path}`, false, String(error)); }
}

const rootPackage = JSON.parse(await read('package.json'));
const apiPackage = JSON.parse(await read('apps/api/package.json'));
const dbPackage = JSON.parse(await read('packages/database/package.json'));
check('Root workspace is private', rootPackage.private === true);
check('API package declares Nest start/build scripts', Boolean(apiPackage.scripts?.['start:dev'] && apiPackage.scripts?.build));
check('Database package declares Prisma client', Boolean(dbPackage.dependencies?.['@prisma/client']));
check('API entrypoint exists', await exists('apps/api/src/main.ts'));
check('Prisma schema exists', await exists('packages/database/prisma/schema.prisma'));

const main = await read('apps/api/src/main.ts');
check('API has versioned route prefix', main.includes("setGlobalPrefix('api/v1')"));
check('API uses Helmet', main.includes('helmet()'));
check('API does not allow wildcard CORS', !/origin\s*:\s*['"]\*['"]/.test(main));
check('API validates port range', main.includes('port < 1 || port > 65535'));

const schema = await read('packages/database/prisma/schema.prisma');
for (const model of ['User', 'Seller', 'Store', 'Product', 'Offer', 'Inventory', 'Order', 'OrderItem']) {
  check(`Schema includes ${model}`, new RegExp(`model\\s+${model}\\s*\\{`).test(schema));
}
check('Money fields use integer storage', /priceIqd\s+BigInt/.test(schema) && /totalIqd\s+BigInt/.test(schema));

let failed = 0;
for (const item of checks) {
  console.log(`${item.passed ? 'PASS' : 'FAIL'} ${item.name}${item.detail ? ` — ${item.detail}` : ''}`);
  if (!item.passed) failed++;
}
console.log(`\nStatic scaffold checks: ${checks.length - failed}/${checks.length} passed.`);
console.log('This is a static consistency check; it does not install dependencies, compile TypeScript, or connect to services.');
if (failed) process.exitCode = 1;
