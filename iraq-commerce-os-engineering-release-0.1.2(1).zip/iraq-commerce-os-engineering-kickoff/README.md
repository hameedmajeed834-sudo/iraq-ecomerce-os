# IRAQ COMMERCE OS — Engineering Kickoff

This repository is a **starter scaffold**, not a finished commerce platform. It establishes a small API foundation and records implementation gates.

## Prerequisites
- Node.js 22 LTS
- pnpm 10 (`corepack enable` can make pnpm available on supported Node installations)
- Docker Desktop / Docker Engine (for local PostgreSQL and Redis)

## First-time setup
```bash
cp .env.example .env
pnpm install
```

On Windows PowerShell, use `Copy-Item .env.example .env` instead of `cp` if needed.

## Start local dependencies
```bash
docker compose up -d postgres redis
```

## Run the API
```bash
pnpm dev:api
```

Liveness endpoint: `GET http://localhost:3000/api/v1/health`

The current health endpoint confirms only that the API process responds. It does **not** prove that PostgreSQL, Redis, or external services are reachable.

## Current engineering scope
- [x] Monorepo starter structure
- [x] Minimal NestJS API and liveness endpoint
- [x] Local PostgreSQL + Redis service definitions
- [x] Initial Prisma identity/catalog/offer/inventory/order schema draft
- [x] Load local `.env` values at API startup
- [x] Validate the configured API port before listening
- [x] Helmet security headers and explicit CORS origin allowlist
- [ ] Install dependencies and run a full build in a developer environment
- [ ] Versioned database migrations and repeatable seed data
- [ ] Real phone OTP provider and secure session lifecycle
- [ ] RBAC/ABAC enforcement and audit events
- [ ] Product/offer APIs with DTO validation and authorization
- [ ] Transaction-safe inventory reservation and order creation
- [ ] Payment integration, double-entry ledger, settlement and reconciliation
- [ ] Logistics, delivery proof, returns and invoices
- [ ] Unit, integration, security and concurrency tests
- [ ] Production deployment, observability, backups and security review

## Security and data notes
- `.env.example` contains development-only placeholders; never reuse them in production.
- Do not use real customer data or production secrets in this scaffold.
- CORS defaults to disabled when `CORS_ORIGINS` is empty. Set exact trusted web-app origins as a comma-separated list; do not use `*` with credentialed requests.
- Helmet adds baseline HTTP security headers, but it is not a substitute for authentication, authorization, rate limiting, input validation, or a security review.
- The database schema is a draft and has not been reviewed for production deployment.

## Verification status
The files have been statically inspected and updated, but dependency installation, compilation, database startup, and endpoint smoke tests have **not** been run in this environment. Treat runtime status as unverified until those checks pass.

## Local verification commands
Run the dependency-free structural check before installing packages:
```bash
npm run verify:scaffold
```
This checks key files, JSON manifests, expected schema models, integer money fields, API prefix, and a few security defaults. It is **not** a substitute for TypeScript compilation, Prisma validation, integration tests, or a security review.

After enabling pnpm and installing dependencies, validate the schema and prepare a development migration with the database running:
```bash
pnpm db:validate
pnpm db:migrate:dev
```
Review generated migrations before committing them. Never run development migration commands against production.
